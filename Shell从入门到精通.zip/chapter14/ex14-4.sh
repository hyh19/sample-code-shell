#! /bin/bash

a=1
if [ "$a" -eq 1 ]
then
   b=2
else
   b=1
fi
c=3

echo "a=$a"
echo "b=$b"
echo "c=$c"

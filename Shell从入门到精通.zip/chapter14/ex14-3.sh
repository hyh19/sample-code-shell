#! /bin/bash

x=1
if [ $x == 1 ]; then
   echo "x=1"
elif [ $x == 0 ]; then
   echo "x=0"
else
   echo "other"
fi


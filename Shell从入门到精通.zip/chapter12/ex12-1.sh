#! /bin/bash

files=`find . -name "*.sh"`

echo "$files"



#! /bin/bash

files=`find /etc /usr/local -name httpd.conf`

echo "$files"

#! /bin/bash

files=`find /etc -name rc[1-9].d -print`

echo "$files"

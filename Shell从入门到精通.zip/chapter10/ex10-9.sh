#-----------------------------/chapter10/ex10-9.sh------------------ 
#! /bin/bash

#ɾ����1��
result=`sed -e '1 d' students.txt`

echo "$result"

#-----------------------------/chapter10/ex10-10.sh------------------
#! /bin/bash

#ɾ�����һ��
result=`sed -e '$ d' students.txt`

echo "$result"

#! /bin/bash

message="Hello world."

source ./output.sh

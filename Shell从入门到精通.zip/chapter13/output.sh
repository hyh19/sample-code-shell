#! /bin/bash

echo "$message"

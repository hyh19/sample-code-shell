#! /bin/bash

cd /var/log
pwd

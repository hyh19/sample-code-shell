#! /bin/bash

ps -ef|grep ps

echo $SHLVL

pidof -x ex13-2.sh

exit 0


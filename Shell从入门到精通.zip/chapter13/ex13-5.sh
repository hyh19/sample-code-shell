#! /bin/bash

(cd /;ls;echo "current working directory is ";pwd)

echo "current working directory is"

pwd

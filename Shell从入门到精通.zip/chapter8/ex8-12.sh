#-----------------------------/chapter8/ex8-12.sh------------------
#! /bin/bash

str=`grep "." demo3.txt`

echo "$str"

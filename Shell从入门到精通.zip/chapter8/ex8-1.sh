#-----------------------------/chapter8/ex8-1.sh------------------
#! /bin/bash

str=`cat version.txt|grep rev`
echo "$str"

#-----------------------------/chapter8/ex8-19.sh------------------
#! /bin/bash

str=`egrep "&nbsp;{2}" html.txt`
echo "$str"

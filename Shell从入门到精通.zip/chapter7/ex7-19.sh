#-----------------------------/chapter7/ex7-19.sh------------------
#! /bin/bash

linux=("Debian" "RedHat" "Ubuntu" "Suse" "Fedora" "UTS" "CentOS")
#������Ƭ
echo ${linux[@]:2:4}

#-----------------------------/chapter7/ex7-26.sh------------------
#! /bin/bash

linux=("Debian" "RedHat" "Ubuntu" "Suse" "Fedora" "UTS" "CentOS")
#��������
linux2=("${linux[@]}")
echo "${linux2[@]}"

#-----------------------------/chapter3/ex3-4.sh------------------
#! /bin/bash

#�����ǰĿ¼
echo "current directory is `pwd`"

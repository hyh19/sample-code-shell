#-----------------------------/chapter9/ex9-16.sh------------------
#! /bin/bash

#��ʽ���ı�ҳ
str=`pr -4 demo4.txt`
echo "$str"

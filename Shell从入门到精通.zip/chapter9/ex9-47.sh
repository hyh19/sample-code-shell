#-----------------------------/chapter9/ex9-47.sh------------------
#! /bin/bash

#ѹ���ظ��ַ�
result=`tr -s "[a-z]" < demo9.txt`

echo "$result"

#-----------------------------/chapter9/ex9-13.sh------------------
#! /bin/bash

#ָ���г���
str=`fmt -c -w 80 demo2.txt`
echo "$str"

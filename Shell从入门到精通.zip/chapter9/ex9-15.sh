#-----------------------------/chapter9/ex9-15.sh------------------
#! /bin/bash

#��ת�ı���
str=`rev demo3.txt`
echo "$str"

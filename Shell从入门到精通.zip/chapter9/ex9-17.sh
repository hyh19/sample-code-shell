#-----------------------------/chapter9/ex9-17.sh------------------
#! /bin/bash

#�Զ���ҳü
str=`pr -h "List of Countries" -a -f -4 demo4.txt`
echo "$str"

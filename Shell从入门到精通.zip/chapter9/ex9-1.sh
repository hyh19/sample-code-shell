#-----------------------------/chapter9/ex-1.sh------------------
echo -n "What is your first name? "
read first
echo -n "What is your last name? "
read last
echo -n "What is your middle name? "
read middle
echo -n "What is your birthday? "
read birthday

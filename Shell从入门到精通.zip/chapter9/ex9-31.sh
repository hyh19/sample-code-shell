#-----------------------------/chapter9/ex9-31.sh------------------  
#! /bin/bash

#ͳ���ı�����
lines=`cat ex9-1.sh | wc -l`

echo "the file has $lines lines."

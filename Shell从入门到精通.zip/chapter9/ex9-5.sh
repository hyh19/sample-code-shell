#-----------------------------/chapter9/ex9-5.sh------------------
#! /bin/bash

echo "You are always in control of your search settings."
echo " Here's a quick review of the options that you can set."

#-----------------------------/chapter9/ex9-38.sh------------------
#! /bin/bash

#�Զ����зָ���
paste -d "," students.txt phones.txt > contactinfo.txt

cat contactinfo.txt

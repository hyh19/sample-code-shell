#-----------------------------/chapter9/ex9-7.sh------------------
#! /bin/bash

#ʹ��ת���ַ����⻻��
echo -e "You are always in control of your search settings.\c"
echo " Here's a quick review of the options that you can set."

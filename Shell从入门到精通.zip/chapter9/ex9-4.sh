#-----------------------------/chapter9/ex9-4.sh------------------
#! /bin/bash

echo -n "Please input a name:"

read name

echo "Hello, $name"

v1="sing"
v2="danc"

echo "We are ${v1}ing, we are ${v2}ing."

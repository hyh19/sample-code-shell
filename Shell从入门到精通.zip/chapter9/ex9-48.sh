#-----------------------------/chapter9/ex9-48.sh------------------
#! /bin/bash

#ɾ���հ���
result=`cat demo10.txt | tr -s ["\n"]`

echo "$result"

#-----------------------------/chapter9/ex9-6.sh------------------
#! /bin/bash

#ʹ��-nѡ������ı�
echo -n "You are always in control of your search settings."
echo " Here's a quick review of the options that you can set."

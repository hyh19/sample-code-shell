#-----------------------------/chapter1/ex1-3.sh------------------
#! /bin/bash

echo "$# parameters"
echo "$@"
